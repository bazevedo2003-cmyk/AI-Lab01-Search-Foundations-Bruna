from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from utils import ucs, gbfs, astar, haversine_km, load_openflights

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "all_datasets"
RESULTS = ROOT / "results" / "lab02"
RESULTS.mkdir(parents=True, exist_ok=True)

# ---------------- Setup ----------------
_, _, coords, graph, _ = load_openflights(DATA / "lab01-03_airports.csv", DATA / "lab01-03_routes.csv")
queries = pd.read_csv("utils/search_queries.csv").head(3)
print(queries)


def report(name, query, result):
    print(f"{query.query_id} {name:<5} {result.path_cost_km:>9,.1f} km  {result.expanded:>5} expanded   "
          f"{' -> '.join(result.path)}")


# ---------------- Question 1: baseline (UCS) ----------------
print("\n=== Question 1: baseline ===")
baseline = {}
for query in queries.itertuples():
    baseline[query.query_id] = ucs(graph, query.start, query.goal)
    report("UCS", query, baseline[query.query_id])


# ---- Question 2 (needed as input for Question 6) ----
def heuristic_to(goal, weight=1.0):
    """h(airport) = weight x great-circle distance from the airport to the goal."""
    def h(airport):
        return weight * haversine_km(coords[airport]["latitude"], coords[airport]["longitude"],
                                     coords[goal]["latitude"], coords[goal]["longitude"])
    return h


informed = {}
print("\n=== Question 2 (prerequisite for Q6): GBFS and A* ===")
for query in queries.itertuples():
    h = heuristic_to(query.goal)
    informed[query.query_id, "GBFS"] = gbfs(graph, query.start, query.goal, h)
    informed[query.query_id, "A*"] = astar(graph, query.start, query.goal, h)
    report("GBFS", query, informed[query.query_id, "GBFS"])
    report("A*", query, informed[query.query_id, "A*"])

# ---- Question 4 (the metrics table that Question 6 plots) ----
rows = []
for query in queries.itertuples():
    results = {"UCS": baseline[query.query_id], "GBFS": informed[query.query_id, "GBFS"],
               "A*": informed[query.query_id, "A*"]}
    for name, result in results.items():
        rows.append({"query_id": query.query_id, "algorithm": name, **result.as_dict(),
                     "path": " -> ".join(result.path)})
metrics = pd.DataFrame(rows).drop(columns="found").rename(columns={"path_cost_km": "cost_km"})
ucs_cost = metrics[metrics.algorithm == "UCS"].set_index("query_id").cost_km
metrics["gap_pct"] = 100 * (metrics.cost_km / metrics.query_id.map(ucs_cost) - 1)
metrics.to_csv(RESULTS / "metrics.csv", index=False)
print("\n", metrics.drop(columns="path").round(2))

# ---------------- Question 6: save the evidence ----------------
print("\n=== Question 6: expanded-nodes figure ===")
effort = metrics[metrics.algorithm.isin(["UCS", "A*", "GBFS"])].pivot(
    index="query_id", columns="algorithm", values="expanded")
print(effort[["UCS", "A*", "GBFS"]])
ax = effort[["UCS", "A*", "GBFS"]].plot.bar(figsize=(8, 4), logy=True)
ax.set(ylabel="Expanded states (log scale)", title="Search effort on the three standard queries")
ax.grid(axis="y", alpha=0.25)
plt.tight_layout()
plt.savefig(RESULTS / "expanded_nodes.png", dpi=160)
print("Saved:", sorted(p.name for p in RESULTS.iterdir()))
